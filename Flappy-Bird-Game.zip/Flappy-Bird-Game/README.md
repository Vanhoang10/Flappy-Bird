# WPF-Flappy-Bird-Game
Hi, in this tutorial we will show you how to make a fun flappy bird game in visual studio using WPF and C# programming language. How to create a flappy bird tutorial was one of the first tutorial we did on this website, we are back now with a new one where we will show you how to make a new and improved version of flappy bird using Microsoft Visual Studio, WPF and C#. in this game you will have your standard pipes and a gap between them where the bird will fly through or fail. Scores are judged between how many pipes you can go through. We will also add two small clouds in the background to scroll through as you are playing the game. This will be fun let’s get started.

Video Tutorial - 

[![](http://img.youtube.com/vi/rdxylTJJv5c/0.jpg)](http://www.youtube.com/watch?v=rdxylTJJv5c "MOO ICT Create a Flappy Bird Game in Visual Studio")

Written Tutorial and Images - 

https://www.mooict.com/wpf-c-create-a-flappy-bird-game-in-visual-studio/

