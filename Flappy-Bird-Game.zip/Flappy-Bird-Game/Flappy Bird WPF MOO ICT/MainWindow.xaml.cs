﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Threading;


namespace Flappy_Bird
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {

        DispatcherTimer gameTimer = new DispatcherTimer();//tạo bộ đếm cho trò chơi


        double score;//tính điểm
        int gravity = 8;//trọng lực, tốc dộ rơi
        bool gameOver;//check 
        Rect flappyBirdHitBox;//cho biết khi nào con chim thực sự chạm vào cột

        public MainWindow()
        {
            InitializeComponent();

            gameTimer.Tick += MainEventTimer;//tạo bộ đếm thời gian
            gameTimer.Interval = TimeSpan.FromMilliseconds(20);//20miligiay
            StartGame();//bắt đầu game

        }

        private void MainEventTimer(object sender, EventArgs e)
        {
            txtScore.Content = "Score: " + score;
            //cập nhật điểm
            flappyBirdHitBox = new Rect(Canvas.GetLeft(flappyBird), Canvas.GetTop(flappyBird), flappyBird.Width - 12, flappyBird.Height);
            //cập nhật vị trí của con chim
            Canvas.SetTop(flappyBird, Canvas.GetTop(flappyBird) + gravity);
            //nếu con chim đi ra ngoài phạm vi trò chơi sẽ kết thúc
            if (Canvas.GetTop(flappyBird) < -30 || Canvas.GetTop(flappyBird) + flappyBird.Height > 460)
            {
                EndGame();
            }


            foreach (var x in MyCanvas.Children.OfType<Image>())
            {   // sự hoạt động di chuyển của các ông cột
                if ((string)x.Tag == "obs1" || (string)x.Tag == "obs2" || (string)x.Tag == "obs3")
                {   //di chuyển ống cột sang trái
                    Canvas.SetLeft(x, Canvas.GetLeft(x) - 5);

                    if (Canvas.GetLeft(x) < -100)
                    {   //điều chỉnh lại khoảng cách của các ống cột
                        // tạo thêm các cột phía sau
                        Canvas.SetLeft(x, 800);
                        //cập nhật điểm
                        score += .5;
                    }
                    
                    Rect PillarHitBox = new Rect(Canvas.GetLeft(x), Canvas.GetTop(x), x.Width, x.Height);
                    //nếu con chim va chạm với ông cột sẽ kết thúc trò chơi
                    if (flappyBirdHitBox.IntersectsWith(PillarHitBox))
                    {
                        EndGame();
                    }
                }

                if ((string)x.Tag == "clouds")
                {   //kiểm tra đặt lại vị trí cho đám mây
                    Canvas.SetLeft(x, Canvas.GetLeft(x) - 1);

                    if (Canvas.GetLeft(x) < -250)
                    {
                        Canvas.SetLeft(x, 550);
                        //cập nhật điểm
                        score += .5;
                    }

                }


            }


        }

        private void KeyIsDown(object sender, KeyEventArgs e)
        {   //nếu ấn phím Space
            if (e.Key == Key.Space)
            {   //con chim sẽ di chuyển đi lên
                flappyBird.RenderTransform = new RotateTransform(-20, flappyBird.Width / 2, flappyBird.Height / 2);
                gravity = -8;
            }
            //khi overgame thì ấn phím R để bắt đầu lại
            if (e.Key == Key.R && gameOver == true)
            {   //bắt đầu trò chơi
                StartGame();
            }
        }

        private void KeyIsUp(object sender, KeyEventArgs e)
        {   //TH không sử dụng phím nào con chim sẽ tự rơi xuống
            flappyBird.RenderTransform = new RotateTransform(5, flappyBird.Width /2, flappyBird.Height /2);

            gravity = 8;
        }

        private void StartGame()
        {
            MyCanvas.Focus();

            int temp = 300;
            //khai báo điểm
            score = 0;
            //game bắt đầu
            gameOver = false;

            Canvas.SetTop(flappyBird, 190);//vị trí đặt con chim

            foreach (var x in MyCanvas.Children.OfType<Image>())
            {   //các ông cột sang trái dần ra khỏi trò chơi
                if ((string)x.Tag == "obs1")
                {
                    Canvas.SetLeft(x, 500);
                }
                if ((string)x.Tag == "obs2")
                {
                    Canvas.SetLeft(x, 800);
                }
                if ((string)x.Tag == "obs3")
                {
                    Canvas.SetLeft(x, 1100);
                }
                //đám mây vẫn được đứng yên nhờ có biến khai báo tạm thời
                if ((string)x.Tag == "clouds")
                {
                    Canvas.SetLeft(x, 300 + temp);
                    temp = 800;
                }
            }

            gameTimer.Start();//bắt đầu bộ đếm tgian
        }

        private void EndGame()
        {
            gameTimer.Stop();
            gameOver = true;
            // Nếu đã login thì mới bắt đầu tính điểm mỗi khi thua
            if (this.loginScreen != null)
                this.loginScreen.updateScore((int)score);
            // Tạo page xem Rank
            // Nếu đã login thì show tab Rank mỗi khi thua
            Rank rank = new Rank();
            if (this.loginScreen != null) 
                this.loginScreen.getRank(rank);
            txtScore.Content += " Game Over!!! Press R to restart.";

        }

        // Tạo biến lưu trang loginScreen
        private LoginScreen loginScreen = null;

        // Tạo hàm lưu Object Login Screen
        public void setObjLoginScreen(LoginScreen obj)
        {
            this.loginScreen = obj;
        }

            

    }
}
