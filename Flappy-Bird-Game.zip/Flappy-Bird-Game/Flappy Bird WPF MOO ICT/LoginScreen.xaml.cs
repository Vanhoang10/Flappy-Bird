﻿using System;
using System.Diagnostics;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Data.SqlClient;
using MySql.Data.MySqlClient;
using System.Security.Cryptography;


namespace Flappy_Bird
{
    /// <summary>
    /// Interaction logic for LoginScreen.xaml
    /// </summary>
    public partial class LoginScreen : Window
    {   //khai báo đường link cơ sở dữ liệu
        private string connetionString = "server=localhost;database=fb_sql;uid=root;pwd=";
        private string username { get; set; }
        public int Score = -1;
        MainWindow mainScreen = null;
        public LoginScreen()
        {
            InitializeComponent();
            
            mainScreen = new MainWindow();
        }


        private void btnLogin_Click(object sender, RoutedEventArgs e)
        {   //nhập tk, mk xong check xem đã đúng hay chưa
            //chưa đúng sẽ hiện thông báo để ng dùng nhập lại
            username = txtUsername.Text;
            string password = txtPassword.Password;
            if (username.Length < 5)
            {
                MessageBox.Show("Tên đăng nhập tối thiểu 5 ký tự ");
                return;
            }
            if (password.Length < 6)
            {
                MessageBox.Show("Mật khẩu tối thiểu 6 ký tự ");
                return;
            }
            try
            {
                // Khởi tạo kết nối với cơ sở dữ liệu
                MySqlConnection conn = new MySqlConnection(connetionString);
                conn.Open();
                MySqlCommand cmd = conn.CreateCommand();

                password = GetHashMD5(password);
                // Gọi Query tới CSDL để kiểm tra tài khoản mật khẩu
                cmd.CommandText = $"SELECT * FROM players WHERE username = '{username}' AND password = '{password}'";
                MySqlDataReader reader = cmd.ExecuteReader();
                Score = -1;
                while (reader.Read())
                {
                    Score = int.Parse(reader.GetString(3));
                }
                // Nếu điểm cao nhất Score không thay đổi => TK, MK sai

                if (Score == -1)
                {
                    MessageBox.Show("Tài khoản hoặc mật khẩu không chính xác!");
                    return;
                }
                MessageBox.Show("Đăng nhập thành công!");
                // Nếu đăng nhập thành công thì truyền tab Login hiện tại lại cho Main, hiển thị trang main và đóng trang Login
                mainScreen.setObjLoginScreen(this);
                mainScreen.Show();
                conn.Close();
                this.Close();
            }
            catch (Exception)
            {   //trong quá trình đăng nhập xảy ra lỗi sẽ hiển thị thông báo
                MessageBox.Show("Có lỗi xảy ra trong quá trình đăng nhập!");
            }

        }


        // Hàm mã hóa string dạng MD5
        public static string GetHashMD5(string plainText)
        {
            MD5 md5 = new MD5CryptoServiceProvider();
            // Compute hash from the bytes of text
            md5.ComputeHash(ASCIIEncoding.ASCII.GetBytes(plainText));
            // Get hash result after compute it
            byte[] result = md5.Hash;
            StringBuilder strBuilder = new StringBuilder();
            for (int i = 0; i < result.Length; i++)
            {
                strBuilder.Append(result[i].ToString("x2"));
            }

            return strBuilder.ToString();
        }

        // Hàm cập nhật điểm cao nhất
        public void updateScore(int newScore)
        {    
            // Kiểm tra điểm hiện tại có cao hơn Score không để thay đổi
            if (Score < newScore)
            {
                // Tạo kết nối CSDL
                MySqlConnection conn = new MySqlConnection(connetionString);
                conn.Open();
                MySqlCommand cmd = conn.CreateCommand();

                // Cập nhật điểm lên CSDL
                cmd.CommandText = $"UPDATE `players` SET `score` = '{newScore}' WHERE `username` = '{this.username}'";
                MySqlDataReader reader = cmd.ExecuteReader();
                conn.Close();
            }
        }

        // Hàm lấy danh sách Rank và hiển thị Tab Rank
        public void getRank(Rank rank)
        {
            // Tạo kết nối CSDL
            MySqlConnection conn = new MySqlConnection(connetionString);
            conn.Open();
            MySqlCommand cmd = conn.CreateCommand();

            // Lấy 2 người chơi có điểm cao nhất
            cmd.CommandText = $"SELECT `score` FROM `players` ORDER BY `score` DESC LIMIT 2";
            MySqlDataReader reader = cmd.ExecuteReader();

            int[] scoreTemp = {0, 0};
            int i = 0;


            while (reader.Read())
            {
                scoreTemp[i] = int.Parse(reader.GetString(0));
                i++;
            }

            // Gán giá trị vừa đọc cho label trong tab Rank và hiển thị tab Rank

            rank.topScore1.Content = scoreTemp[0];
            rank.topScore2.Content = scoreTemp[1];

            conn.Close();
            rank.Show();
        }
    }

}