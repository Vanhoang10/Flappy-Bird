﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Flappy_Bird
{
    /// <summary>
    /// Interaction logic for Rank.xaml
    /// </summary>
    public partial class Rank : Window
    {
        public Rank()
        {
            InitializeComponent();
        }


        //tạo sự kiện tắt tab rank
        private void btn_exit_rank(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}
